<?php 
require_once('header.php');
get_template_part('content');

get_footer( );



 ?>