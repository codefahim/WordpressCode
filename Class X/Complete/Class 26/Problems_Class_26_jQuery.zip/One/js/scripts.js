jQuery(document).ready(function(){


	jQuery(".btn").click(function(){
		jQuery(".box").Toggle(2000);
	});
});