<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php get_header( ); ?>
	<?php the_post(); the_content(); ?>

	<?php get_footer(); ?>
</body>
</html>