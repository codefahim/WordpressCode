<?php
add_action('after_setup_theme','fox_theme_function');
function fox_theme_function(){
	add_theme_support('title-tag');
	add_theme_support('custom-header');
}

add_action('wp_enqueue_scripts','my_files_attached');
function my_files_attached(){
	wp_enqueue_style('animate_css',get_template_directory_uri().'/css/animate.css');
	wp_enqueue_style('bootstrap_css',get_template_directory_uri().'/css/bootstrap.min.css');
	wp_enqueue_style('main_css',get_template_directory_uri().'/style.css');
	wp_enqueue_style('theme_css',get_template_directory_uri().'/css/style.css');

	wp_enqueue_script('jQuery','js/jquery.min.js',array(),'1.0.0','true');
	wp_enqueue_script('boostrap_js','js/bootstrap.min.js',array(),'1.0.0','true');
	wp_enqueue_script('parallax','js/parallax.js',array(),'1.0.0','true');
	wp_enqueue_script('wow_js','js/wow.js',array(),'1.0.0','true');
	wp_enqueue_script('jQuery','js/main.js',array(),'1.0.0','true');


}















 ?>