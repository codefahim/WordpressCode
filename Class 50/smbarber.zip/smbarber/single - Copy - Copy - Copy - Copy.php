<?php 
wp_head();

wp_footer();


 ?>