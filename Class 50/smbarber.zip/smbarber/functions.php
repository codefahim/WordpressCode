<?php 

add_action('after_setup_theme','support_function');
function support_function(){
	add_theme_support('title-tag');
	add_theme_support('custom-background');
	add_theme_support('custom-header');

	register_nav_menu( 'main_menu', 'Main Menu');
	register_nav_menu( 'side_menu', 'Side Menu');

};
































add_action('wp_enqueue_scripts','my_files');

function my_files(){
	wp_enqueue_style('bootstrap_css',get_template_directory_uri().'/css/bootstrap.min.css');
	wp_enqueue_style('main_css',get_template_directory_uri().'/style.css');
	wp_enqueue_style('colors_css',get_template_directory_uri().'/css/colors.css');
	wp_enqueue_style('versions_css',get_template_directory_uri().'/css/versions.css');
	wp_enqueue_style('responsive_css',get_template_directory_uri().'/css/responsive.css');
	wp_enqueue_style('custom_css',get_template_directory_uri().'/css/custom.css');

	wp_enqueue_script( 'all_js',get_template_directory_uri().'/js/all.js',array(),'1.0.0','true' );
	wp_enqueue_script( 'responsive_js',get_template_directory_uri().'/js/responsive-tabs.js',array(),'1.0.0','true' );
	wp_enqueue_script( 'custom_js',get_template_directory_uri().'/js/custom.js',array(),'1.0.0','true' );
}












 ?>